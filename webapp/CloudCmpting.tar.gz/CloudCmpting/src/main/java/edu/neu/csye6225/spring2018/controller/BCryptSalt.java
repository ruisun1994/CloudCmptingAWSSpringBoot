package edu.neu.csye6225.spring2018.controller;

public class BCryptSalt {
    public static final String SALT = "$2a$10$7Y4Qmeg39QAf/oQxBhSJL.";
}
